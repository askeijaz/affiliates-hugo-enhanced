---
title: "We all wait for summer"
date: 2025-04-03T08:24:00+00:00
draft: false
image: "images/post-image-4.jpeg"
author: "Sal"
categories: ["IT","Data Visualization"]
tags: ["SQL", "VBA"]
---

This is changed. As I engage in the so-called "bull sessions" around and about the school, I too often find that most college men have a misconception of the purpose of education. Most of the "brethren" think that education should equip them with the proper instruments of exploitation so that they can forever trample over the masses. Still others think that education should furnish them with noble ends rather than means to an end.

It seems to me that education has a two-fold function to perform in the life of man and in society: the one is utility and the other is culture. Education must enable a man to become more efficient, to achieve with increasing facility the ligitimate goals of his life.
