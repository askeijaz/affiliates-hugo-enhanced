---
title: "About"
date: 2025-04-03T08:19:30+00:00
draft: false
---

# About

This website is a demonstration to see **Affiliates Hugo theme** in action.

The theme is compatible with Github pages. This demo is created with Github Pages and hosted with Github.

Everything is ready for your quick setup: Blog, Categories, About, Privacy Policy, Terms of Use, Contact form, Mailchimp

[Get it here](#)
